<?php
class ApiCall {
		
	private $validate;
	const DEFAULT_MAX_REDIRECTS = 1;
	const MAX_TIMEOUT = 60;
	
	public function __construct() {
		$this->validate = new Validation();
	}
	
	public function validate() {
		return $this->validate;
	}
	
	/*
	 * Executes an API call, and parses the response.
	 * If there is a failure in the request, or a failure in the response, an exception of type  ApiCallException is thrown.
	 * the returned content array will have:
	 * content: the text content, or decoded JSON object
	 * statusCode: the HTTP status code
	 * headers: an array containing HTTP headers in lowercase
	 *
	 * if the status code is not ok (e.g. not 200/201) and the content type is json, then we look for
	 *	a JSON property called errorCode in response. If it is set then the value of getCode of the exception thrown will have
	 * this parsed value.
	 *
	 * @param string $webservice_url 	URL to call
	 * @param string $http_method 		HTTP method to use
	 * @param array $parameters 		Parameters to send. will be urlencoded and attached to
	 *                                  request automatically with support to GET,POST,PUT DELETE HTTP methods.
	 * @param string $options 			Configures the options for making the request.
	 *                                  timeout: the timeout for the request after which exception will be generated.
	 *                                  		 0 means wait indefinitely.
     *                                           the default timeout is system defined. 
	 *                                  max_redirects: the number of HTTP redirects to follow, including HTTP 3XX and 201 redirects.
	 *                                                 by default, redirects are NOT followed!
	 * Returns body, status code and headers (in lowercase). 
	 */
	public function wsCall_FileGetContents($webservice_url, $http_method, $parameters = null, $options = null) {
		$http_method = strtoupper($http_method);
        $http = array(
        	'ignore_errors' => true,
            'method'=> $http_method);
        
        // set timeout if it's given
        if (is_array($options) && array_key_exists('timeout', $options)) {
        	$http['timeout'] = $options['timeout'];
        }
        
        // set max_redirects if it's given
        if (is_array($options) && array_key_exists('max_redirects',$options) && $options['max_redirects'] != self::DEFAULT_MAX_REDIRECTS) {
        	$http['max_redirects'] = $options['max_redirects'];
        }
        
        // build query string and append it to web service url
        if ( ($http_method=='GET') || ($http_method=='DELETE') ) {
	        $query ='';
	        if ($parameters && is_array($parameters)) {
				foreach($parameters as $key=>$value) {
					if ($value || $value == 0) {
						$query.= ($query=='' ? '?' : '&');  
						$query .= $key.'='.urlencode($value);
					}
				}
	        }
	        $webservice_url .= $query;
        }
        else if ($http_method=='POST' || $http_method=='PUT') {
        	
        	//URL-encode query string
        	if ($parameters && is_array($parameters)) {        		
        		$http['header']  = "Content-type: application/x-www-form-urlencoded; charset=utf-8\r\n";
        		$http['content'] = http_build_query($parameters);
        	}
        }
        
        // create stram context and make request
		$opts = array('http' => $http);		
		$context = stream_context_create($opts);
		
		error_log("Sending HTTP request ".$http_method." ".$webservice_url);
		
		$content = @file_get_contents($webservice_url, false, $context);
		
		// parse and validate http status code
        $status_code = explode(' ',$http_response_header[0], 3);
        $header_code = $status_code[1];
		error_log("Received HTTP response ".$header_code." length: ".strlen($content));
        		
        // parse http response headers, if there is some HTTP status code and its not a timeout
        if ($header_code)
        {
			$headers = array();
			for ($i=0; $i<count($http_response_header); $i++) {
				$h  = $http_response_header[$i];
				$p = strpos($h,':');
				if ($p === false) continue;
				$headers[strtolower(substr($h, 0, $p))] = ltrim( substr($h, $p+1) );			
			}
			
			// JSON decode.
			
			
			// if response content format is JSon, validate and return decoded response
			if ($headers["content-type"] && strpos(strtolower($headers["content-type"]),"application/x-javascript")!==false) {
				$obj = json_decode($content);			
				if ($obj==null) {
					// set json decode error flag
					throw new ApiCallException($webservice_url." JSON decode failed", $header_code, $content, 0, true);
				}
				else if (isset($obj->errorCode))
				{				
					// set exception error code and json decode error flag
					throw new ApiCallException($webservice_url." failed with application defined code", $header_code, $obj, $obj->errorCode, false);
				}
				else 
				{
					// set http body
					$content = $obj;				
				}
	        }
	    }
       	$this->validate()->ResponseHeaderValidation($header_code, $content, $webservice_url);

       	$arrReturn = array();
       	$arrReturn['content'] = $content;
		$arrReturn['statusCode'] = $header_code;
		$arrReturn['headers'] = $headers;
		
        return $arrReturn;
	}



	public function wsCall($webservice_url, $http_method, $parameters = null, $options = null) {
		$http_method = strtoupper($http_method);

		// create a new cURL resource
		$curl_handle = curl_init();

		// set request method
		curl_setopt($curl_handle, CURLOPT_CUSTOMREQUEST, $http_method);

		$parameterstring = http_build_query($parameters);
		// If flatten_arrays is set, arrays of the form foo[0]=1&foo[1]=2 will be flattened into foo=1&foo=2,
		// with the key specified multiple times
		if (is_array($options) && array_key_exists('flatten_arrays', $options)) {
			error_log("flattening param string: ".$parameterstring);
			$parameterstring = ereg_replace('%5B[0-9]+%5D','',$parameterstring);
		}

		// build query string and append it to web service url
		if ( ($http_method=='GET') || ($http_method=='DELETE') ) {
			$webservice_url .= '?'.$parameterstring;
		}
		else if ($http_method=='POST' || $http_method=='PUT') {
			//URL-encode query string
			curl_setopt($curl_handle, CURLOPT_POST, true);
			curl_setopt($curl_handle, CURLOPT_POSTFIELDS, $parameterstring);
		}


		// set URL
		curl_setopt($curl_handle, CURLOPT_URL, $webservice_url);

		// The number of seconds to wait while trying to connect. Use 0 to wait indefinitely.
		if (is_array($options) && array_key_exists('timeout', $options)) {
			curl_setopt($curl_handle, CURLOPT_TIMEOUT, $options['timeout']);
		}
		else
		{
			curl_setopt($curl_handle, CURLOPT_TIMEOUT, self::MAX_TIMEOUT);
		}

		// set max_redirects if it's given
		if (is_array($options) && array_key_exists('max_redirects',$options) && $options['max_redirects'] != self::DEFAULT_MAX_REDIRECTS) {
			curl_setopt($curl_handle, CURLOPT_MAXREDIRS, $options['max_redirects']);
		}
		else {
			// default is 20, then we must be set our default value here (http://php.net/manual/en/context.curl.php).
			curl_setopt($curl_handle, CURLOPT_MAXREDIRS, self::DEFAULT_MAX_REDIRECTS);
		}
		curl_setopt($curl_handle, CURLOPT_FOLLOWLOCATION, true);

		// get the response as a string from curl_exec(), rather than echoing it
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, true);

		// include headers in the response (to get the location after a POST request)
		curl_setopt($curl_handle, CURLOPT_HEADER, true);

		// Prevent use of the Expect: header which causes HTTP 417 errors with lighttpd
		// see http://www.shesek.info/php/http-error-417-with-php-curl
		curl_setopt($curl_handle, CURLOPT_HTTPHEADER, array('Expect:'));

		error_log("Sending HTTP request ".$http_method." ".$webservice_url);

		$content = curl_exec($curl_handle);
		$arrReturn = $this->parse_curl_response($content);
		$content = $arrReturn['content'];
		$contentType = curl_getinfo($curl_handle, CURLINFO_CONTENT_TYPE);
		curl_close($curl_handle);

		error_log("Received HTTP response ".$arrReturn['statusCode']." length: ".strlen($content)." type: ".$contentType);

		// if response content format is JSon, validate and return decoded response
		if ($contentType && strpos(strtolower($contentType),"application/x-javascript")!==false) {
			$obj = json_decode($content);
			
			if ($obj==null) {
				// set json decode error flag
				throw new ApiCallException($webservice_url." JSON decode failed", $arrReturn['statusCode'], $content, 0, true);
			}
			else if (isset($obj->errorCode))
			{
				// set exception error code and json decode error flag
				throw new ApiCallException($webservice_url." failed with application defined code", $arrReturn['statusCode'], $obj, $obj->errorCode, false);
			}
			else
			{
				// set http body
				$content = $obj;
			}
		}

		$this->validate()->ResponseHeaderValidation($arrReturn['statusCode'], $content, $webservice_url);

		$arrReturn['content'] = $content;
		$arrReturn['url'] = $webservice_url;

		return $arrReturn;
	}


	public function parse_curl_response($response)
	{
		// Split response into header and body sections
		list($response_headers, $response_body) = explode("\r\n\r\n", $response, 2);
		$array_response_headers = explode("\r\n", $response_headers);
			
		// First line of headers is the HTTP response code
		$http_response_line = array_shift($array_response_headers);
		if(ereg('^HTTP/[0-9]\.[0-9] ([0-9]{3})', $http_response_line, $matches)) {
			$status_code = $matches[1];
		}
			
		// put the rest of the headers in an array
		$array_headers = array();
		foreach($array_response_headers as $header_line)
		{
			list($header,$value) = explode(': ', $header_line, 2);
			$array_headers[strtolower($header)] = trim($value);
		}
			
		return array('statusCode' => $status_code,
					 'headers'    => $array_headers,
					 'content'    => $response_body);
	}
}


class Validation {

	public function ResponseHeaderValidation($header_code, $content, $url) {
		switch($header_code) {
			case 200:
			case 201:
			case 202:
				return;
			case 503:
				throw new ApiCallException( ($content!='' ? $content : 'Web Service unavailable'), $header_code, $content );
			case 403:
				throw new ApiCallException( ($content!='' ? $content : 'Request Forbidden'), $header_code, $content );
			case 400:
				throw new ApiCallException( ($content!='' ? $content : 'Bad request.'), $header_code, $content );
			case null:
				throw new ApiCallException( 'Timeout', $header_code, $content );
			default:
				throw new ApiCallException( ($content!='' ? $content : 'Unknown HTTP status'), $header_code, $content );
		}
	}
}

class ApiCallException extends Exception {	
	private $httpStatus;
	private $jsonDecodeError = false;
	private $httpBody;
	
	public function __construct($message, $httpStatus, $httpBody, $errorCode=0, $jsonDecodeError=false) {
		$this->httpStatus= $httpStatus;
		$this->httpBody = $httpBody;
		$this->jsonDecodeError = $jsonDecodeError;
		// message and code are populated in parent class	
		parent::__construct($message, $errorCode);
	}
	
	public function getHttpStatus() {
		return $this->httpStatus;
	}
	
	public function isJsonDecodeError()
	{
		return $this->jsonDecodeError;
	}
	
	public function getHttpBody()
	{
		return $this->httpBody;
	}
	
	// formatted string for display
	public function __toString()
	{
		return __CLASS__ . ':<br/>'. 
				'Message: '. 		$this->message 		.' <br/>'.
				'Code: '. 			$this->code 		.' <br/>'.
				'File: '.			$this->file			.' <br/>'.
				'Line: '.			$this->line			.' <br/>'.
				'Http Status: '.	($this->httpStatus===NULL?'null':$this->httpStatus) .' <br/>'.
				'Http Body: '.		print_r($this->httpBody,true)		.' <br/>'.
				'JSon Decode Error: '.($this->jsonDecodeError?'true':'false') .' <br/>'.
				'Trace: '.			$this->getTraceAsString()			.' <br/>';
	}
}
?>
