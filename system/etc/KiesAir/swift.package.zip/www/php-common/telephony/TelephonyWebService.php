<?php
error_reporting(E_ALL);
require_once dirname(__FILE__) .'/../api_call.php';

define('SORT_TIMESTAMP_ASCENDING',  'time-ascending');
define('SORT_TIMESTAMP_DESCENDING', 'time-descending');
define('START_INDEX', 'startIndex');
define('MAX_ITEMS', 'maxItems');

class CallLog {	
	public $id;
	public $source;
	public $destination;	
	public $sourceName;
	public $destinationName;
	public $sourceContactId;
	public $destinationContactId;
	public $timestamp;
	public $flags = array();
}


class TelephonyWebService extends ApiCall {
	
	private $webservices_url;
	
	function __construct() {
		parent::__construct();
		$this->webservices_url = "http://". '127.0.0.1:'.$_SERVER['SERVER_PORT'] ."/ws/telephony";
	}
	
	public function remove($ids) {
		if (is_array($ids)) {
			foreach ($ids as $id) {
				$this->DeleteSingleItem($id);
			}
		} 
		else {
			$this->DeleteSingleItem($ids);
		}
	}

	private function DeleteSingleItem($id) {
		$url = $this->webservices_url.'/log/'.$id;
		$this->wsCall($url, 'DELETE');
	}
	
	
	public function search($startIndex, $maxItems, $sort, $searchQuery) {	
		$param = array(	START_INDEX => $startIndex, 
						MAX_ITEMS	=> $maxItems, 
						'sort'		=> $sort, 
						'searchQuery'	=> $searchQuery);
		
		$arrResponse = $this->wsCall($this->webservices_url.'/log', 'GET', $param);
		$obj = $arrResponse['content'];
		
		$callList=array();
		foreach($obj->items as $var) {
			$call = new CallLog();
			$call->id 					= $var->id;					
			$call->source				= $var->source;
			$call->destination 			= $var->destination;			
			$call->sourceName 	        = $var->sourceName;
			$call->destinationName		= $var->destinationName;
			$call->sourceContactId		= $var->sourceContactId;
			$call->destinationContactId	= $var->destinationContactId;			
			$call->timestamp			= $var->timestamp;
			$call->flags				= $var->flags;
			$callList[]=$call;
			
		}
		return $callList;		
	}
	
	public function getList($startIndex, $maxItems, $sort) {
		return $this->search($startIndex, $maxItems, $sort, '');
	}
	
	public function call($phone) {
        $params = array('telNum' => $phone);
        $arrResponse = $this->wsCall($this->webservices_url.'/calls', 'POST', $params);
		$location = $arrResponse['headers']['location'];
        return substr($location, strrpos($location, '/')+1); // pase the new {id} from: Location:/ws/telephony/calls/{id}
    }
    
	public function endCall($id) {
		$arrResponse = $this->wsCall($this->webservices_url.'/calls/'.$id, 'DELETE');
    }
    
	public function hasTerminateCapability() {
    	$arrResponse = $this->wsCall($this->webservices_url.'/capabilities', 'GET');
        $obj = $arrResponse['content'];
        return in_array( 'terminate', $obj);
    }
}
?>