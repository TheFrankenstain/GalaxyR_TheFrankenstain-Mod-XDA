<?php
/*
 * argument $contentDispotition must be "attachment" to download or "inline" to reproduce/view
 */
function send_file($path, $mtype, $cacheTime, $contentDispotition) {
	$stat = stat($path);
	if ($stat === FALSE) throw new Exception ("send_file - ". $path . " not accessible");
	$lastModifiedTimestamp = $stat['mtime'];
	$daterfc822 = date(DATE_RFC822,$lastModifiedTimestamp);
	$daterfc822Expiration = date(DATE_RFC822,time() + $cacheTime);
	if ($_SERVER["HTTP_IF_MODIFIED_SINCE"]==$daterfc822)
	{
		header("Status: 304");
		header("__Last-Modified: ".$daterfc822);
		exit();
	}
	header("Status: 200");
	header("Last-Modified: ".$daterfc822);
	header("Expires:".$daterfc822Expiration);
	header("Cache-Control: public, max-age=".$cacheTime);
	header( "X-Sendfile: ".$path);
	if (!$mtype) throw new Exception("mtype must not be null");
	header( "Content-Type: ". $mtype);
	header("Content-Length: ". $stat['size']);
	header( "Content-Disposition: ". $contentDispotition ."; filename=\"". str_replace('+',' ',urlencode(basename($path)) ) ."\"");
}
?>