<?php

function saveState($repeat, $shuffle) {
	$allowed_repeat = array(0, 1, 2);
	$allowed_shuffle = array(0, 3);

	$filename = "MusicPlaylistSettings.ini";

	if (!$file = fopen($filename, 'w')) {
		echo_error("Cant' open file");
		exit;
	}

	if (!$repeat || !in_array($repeat, $allowed_repeat))
		$repeat = 0;
	if (!$shuffle || !in_array($shuffle, $allowed_shuffle))
		$shuffle = 0;

	$str = ("repeat=".($repeat)."\nshuffle=".($shuffle));
	if (!fwrite($file, $str)) {
		echo_error("Can't write to a file");
		fclose($file);
		exit;
	}

	send_json_response("{\"status\":\"success\"}");
	fclose($file);
}

function getState() {
	$filename = "MusicPlaylistSettings.ini";

	if ((($file_contents = file($filename)) === FALSE) || strlen($file_contents) == 0) {
		send_json_response("{\"repeat\":\"0\", \"shuffle\":\"0\"}");
		exit;
	}

	$return_values = array();
	foreach($file_contents as $value) {
		$values = explode("=", trim($value));
		$return_values[] = "\"".$values[0]."\":\"".$values[1]."\"";
	}
	send_json_response("{".join(",", $return_values)."}");
}

function echo_error($message) {
	$error_message = "{\"status\": \"error\", \"description\":\"".$message."\"}";
	send_json_response($error_message);
}

function send_json_response($response_json) {
	header("Content-Type: application/json");
	echo($response_json);
}

switch ($_GET["action"]) {
	case "save":
		saveState($_POST["repeat"], $_POST["shuffle"]);
		break;
	case "load":
		getState();
		break;
	default:
		echo_error("Don't know such action");
}

?>
