<?php
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Pragma: no-cache');

if(isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
	$acceptLanguageHeader = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
	$acceptLanguages = explode(",", $acceptLanguageHeader);
	$languages = array();
	$defaultLanguage = "en-GB";
	$supportedLanguages = array("ar-AR","as-AS","az-AZ","bg-BG","bn-BN","ca-CA","cs-CS","da-DA","de-DE","el-EL","en-PH","en-US","en-GB","es-ES","es_US","et-ET","eu-EU","fa-FA","fi-FI","fr-FR","fr_CA","ga-GA","gl-GL","gu-GU","ha-HA","he-HE","hi-HI","hr-HR","hu-HU","hy-HY","id-ID","ig-IG","is-IS","it-IT","ja-JA","jv-JV","ka-KA","kk-KK","kn-KN","ko-KR","lt-LT","lv-LV","mk-MK","ml-ML","mr-MR","ms-MS","nl-NL","no-NO","or-OR","pa-PA","pl-PL","pt-PT","pt_BR","ro-RO","ru-RU","si-SI","sk-SK","sl-SL","sr-SR","sv-SV","sw-SW","ta-TA","te-TE","th-TH","tr-TR","uk-UK","ur-UR","uz-UZ","vi-VI","yo-YO","zh-HK","zh-SG","zh-TW","zh-ZH",
								"ar","as","az","bg","bn","ca","cs","da","de","el","en","es","et","eu","fa","fi","fr","ga","gl","gu","ha","he","hi","hr","hu","hy","id","ig","is","it","ja","jv","ka","kk","kn","ko","lt","lv","mk","ml","mr","ms","nl","no","or","pa","pl","pt","ro","ru","si","sk","sl","sr","sv","sw","ta","te","th","tr","uk","ur","uz","vi","yo","zh");

	if(sizeof($acceptLanguages > 0)) {
		foreach($acceptLanguages as $language) {
			$parsedLanguage = explode(";", $language);
			$exist = false;
 
			if (!in_array($parsedLanguage[0], $supportedLanguages)) {
			    $exist = true;
			}
 
			foreach($supportedLanguages as $i => $value){			
				 if ($parsedLanguage[0] == strtolower($supportedLanguages[$i])) {
						 	$parsedLanguage[0] = $supportedLanguages[$i];
						 	$exist = false;
						 	break;
				  }
			}
			if($exist == true) {
				$langCode = substr($parsedLanguage[0], 0, 3);
				if ($langCode == 'nn' || $langCode == 'nb' || $langCode == 'nn-' || $langCode == 'nb-') {
						$parsedLanguage[0] = 'no-NO';
				} else {
					foreach($supportedLanguages as $i => $value){
						$lang = strpos($supportedLanguages[$i], $langCode);
						
						if($lang !== false) {
	   				  		$parsedLanguage[0] = $supportedLanguages[$i];   				  		
	   				  	}
					}
				}
			}			
			
			array_push($languages, $parsedLanguage[0]);
		}
		
		$languages = array_unique($languages);
		
		foreach($languages as $language) {
			if(in_array($language, $supportedLanguages)) {
				$defaultLanguage = $language;
				break;
			}
		}
	}
	echo "{\"defaultLanguage\":\"" . $defaultLanguage . "\"}";
}
?>