﻿<?php
$method = $_GET['method'];
$start = $_GET['start'];
$end = $_GET['end'];
$maxItems = $_GET['maxItems'];
$ids = $_GET['ids'];

$tasks = '{"items":[{"id":"1","title":"Create task","time":"1 AM"},{"id":"2","title":"My task","time":"2 AM"}],"size":2}';

$res = "";
if( "getEvents" == $method ){    
    $res = '{"items":[{"id":"2","calendar_id":"2","id":"2","begin":1301919720,"end":1301919720,"title":"654564","description":"56STUB4654","timezone":"Europe/Kiev","location":"","allday":0},{"id":"4","calendar_id":"2","id":"3","begin":1302079740,"end":1302079740,"title":"GL meeting","description":"New feature","timezone":"Europe/Kiev","location":"","allday":0},{"id":"5","calendar_id":"2","id":"4","begin":1302249600,"end":1302253200,"title":"Gohome","description":"","timezone":"Europe/Kiev","location":"","allday":0},{"id":"6","calendar_id":"2","id":"1","begin":1305321127,"end":1305321127,"title":"Tjpk\nV","description":"Tht","timezone":"Europe/Kiev","location":"","allday":0},{"id":"7","calendar_id":"1","id":"5","begin":1306151752,"end":1306151752,"title":"Derswqa","description":"Hhi","timezone":"","location":"Ggghh","allday":0}, {"id":"8","calendar_id":"2","id":"8","begin":1305577078,"end":1305577078,"title":"Test\nV","description":"Tht","timezone":"Europe/Kiev","location":"","allday":0}, {"id":"9","calendar_id":"2","id":"9","begin":1305752152,"end":1305752152,"title":"todayTest","description":"Tht","timezone":"Europe/Kiev","location":"","allday":0}]}';
}
else if( "getTasks" == $method ) {
    $res = '{"items": [{"id":"35","calendar_id": "1","id": "35","begin": "1303986651405","end": "1303986651405","title": "Visit meating (Thu Apr 28 2011 13:41:34)","description": "Don\'t forget visit meating","timezone": "Europe/London" ,"location":"Erels house","allday":"0"},{"id":"36","calendar_id": "1","id": "36","begin": "1303816580000","end": "1303827380000","title": "My Task (Thu Apr 26 2011 14:16:20)","description": "Task description","timezone": "Europe/London","location":"London zoo","allday":"1"} ], "size":"2"}';
}
else if( "getCalendars" == $method ) {
    $res = '{"calendars":[{"id":"1","name":"My calendar","color":"04B5FF","accountName":"local"},{"id":"2","name":"godsavethequeen666@gmail.com","color":"182C57","accountName":"godsavethequeen666@gmail.com"},{"id":"3","name":"1m68812333htv49q0mvrp44as8@group.calendar.google.com","color":"691426","accountName":"godsavethequeen666@gmail.com"},{"id":"4","name":"Дні народження та події контактів","color":"2952A3","accountName":"godsavethequeen666@gmail.com"},{"id":"5","name":"Українські свята","color":"2952A3","accountName":"godsavethequeen666@gmail.com"},{"id":"6","name":"1m68812333htv49q0mvrp44as8@group.calendar.google.com","color":"691426","accountName":"1godsavethequeen666@gmail.com"},{"id":"7","name":"Дні народження та події контактів","color":"2952A3","accountName":"1godsavethequeen666@gmail.com"},{"id":"8","name":"Українські свята","color":"2952A3","accountName":"1godsavethequeen666@gmail.com"}]}';
}
else if( "getEvent" == $method ) {
    $res = '{{"id":"33","calendar_id": "1","id": "33","begin": "1303986651405","end": "1303986651405","title": "Party at Erels (Thu Apr 28 2011 13:41:34)","description": "Party","timezone": "Europe/London" ,"location":"Erels house","allday":"0"}';

}
else if( "addEvent" == $method ) {
    $status = '{"status":"success", "id":"77"}';

}
else if( "editEvent" == $method ) {
    $status = '{"status":"success"}';

}

echo ($res);
?>
