#!/usr/bin/env python
# -*- coding: utf-8 -*-

import shutil
import os
import sys
try:
	from shutil import ignore_patterns
except ImportError:
	print ("Use Python v2.7")
	sys.exit()

def dir_list(dir_name, subdir, *args):
    '''Return a list of file names in directory 'dir_name'
    If 'subdir' is True, recursively access subdirectories under 'dir_name'.
    Additional arguments, if any, are file extensions to add to the list.
    Example usage: fileList = dir_list(r'H:/TEMP', False, 'txt', 'py', 'dat', 'log', 'jpg')
    '''
    fileList = []
    for file in os.listdir(dir_name):
        dirfile = os.path.join(dir_name, file)
        if os.path.isfile(dirfile):
            if len(args) == 0:
                fileList.append(dirfile)
            else:
                if os.path.splitext(dirfile)[1][1:] in args:
                    fileList.append(dirfile)
 
        # recursively access file names in subdirectories
        elif os.path.isdir(dirfile) and subdir:
            # print "Accessing directory:", dirfile
            fileList += dir_list(dirfile, subdir, *args)
    return fileList
  
def combine_files(fileList, fn):
    f = open(fn, 'w')
    for file in fileList:
	    try:
		    f.write(open(file).read()) 
	    except:
		    print("Exception during combine files")
    f.close()

def copyFiles(dir):
	shutil.copytree("release", dir, ignore=ignore_patterns('.svn', '*.bat'))
	folderList = ["css", "images", "swf", "php", "js/localization"]
	for folder in folderList:
		shutil.copytree(folder, dir+"/"+folder, ignore=ignore_patterns('.svn'))

def makeJSFiles(dir): 
	# all JS Files
	alljs = [ "js/iframework/baseClass.js", "js/utils/browserDetect.js","js/iframework/widgetVscroll.js", "js/iframework/widgetSystem.js","js/iframework/widgetManager.js","js/iframework/widgetPopup.js", "js/iframework/widgetLanguage.js","js/iframework/settingsManager.js","js/iframework/sendAjax.js","js/commands/serviceCommand.js","js/iframework/languagePopup.js","js/iframework/confirmationPopup.js","js/iframework/liveNotifications.js", "js/iframework/iframework.js","js/utils/selectBox.js", "js/utils/contactParser.js", "js/utils/utils.js", "js/iframework/popup/welcomePopup.js","js/iframework/popup/confirmDialog.js","js/iframework/popup/checkableDialog.js","js/iframework/popup/createDesktopLinkPopup.js","js/portlets/basePortlet.js","js/fileTransfer/transferFileManager.js","js/widgets/base/baseWidget.js","js/widgets/base/baseList.js","js/widgets/base/menuList.js","js/widgets/base/baseListItem.js","js/widgets/base/basePopup.js","js/widgets/base/baseQueryPopup.js","js/widgets/base/baseGalleryItem.js","js/widgets/player/seekbar.js","js/widgets/player/musicPlayList.js","js/widgets/player/playListItem.js","js/widgets/player/musicPlayer.js","js/widgets/player/playerTicker.js","js/widgets/player/museplayer.js","js/widgets/player/musicPlaylistView.js","js/widgets/popups/confirmDeleteQueryPopup.js","js/widgets/popups/confirmCancelQueryPopup.js"]
	combine_files(alljs, dir + "/js/all.js")
	
	# bookmaks files
	bookmarks = dir_list("js/widgets/bookmarks", False)
	bookmarks.extend(["js/portlets/bookmarksPortlet.js","js/commands/bookmarksCommands.js"])
	combine_files(bookmarks, dir + "/js/bookmarks.js")
	
	# calendar
	calendar = ["js/utils/drag.js","js/iframework/calendarWidget.js","js/widgets/calendar/popup/baseTabbedPopup.js","js/widgets/calendar/popup/calendarActionRecurringEventPopup.js","js/widgets/calendar/popup/calendarDeleteRecurringEventPopup.js","js/widgets/calendar/popup/calendarEditRecurringEventPopup.js","js/widgets/calendar/popup/addCalendarEventPopup.js","js/widgets/calendar/popup/calendarEventPopup.js","js/widgets/calendar/popup/calendarEventFloatingPopup.js","js/widgets/calendar/popup/calendarSwitchPopup.js","js/widgets/calendar/popup/calendarTaskDetailsPopup.js", "js/widgets/calendar/popup/calendarDetailEventPopup.js","js/widgets/calendar/popup/calendarAllEventsDetailsPopup.js","js/widgets/calendar/popup/calendarViewYearPopup.js","js/widgets/calendar/popup/calendarAllDayPopup.js","js/widgets/calendar/baseCalendarView.js","js/widgets/calendar/calendarList.js","js/widgets/calendar/eventView.js","js/widgets/calendar/listView.js","js/widgets/calendar/monthView.js","js/widgets/calendar/taskView.js","js/widgets/calendar/weekView.js","js/widgets/calendar/maxTaskView.js","js/widgets/calendar/searchView.js","js/widgets/calendar/taskSearchView.js","js/portlets/calendarPortlet.js","js/commands/calendarCommands.js"]
	
	combine_files(calendar, dir + "/js/calendar.js")
	
	# calls
	calls = dir_list("js/widgets/calls", False)
	calls.extend(["js/portlets/callsPortlet.js","js/commands/callsCommands.js"])
	combine_files(calls, dir + "/js/calls.js")
	
	# contacts
	contacts = dir_list("js/widgets/contacts", False)
	contacts.extend(["js/portlets/contactsPortlet.js","js/commands/contactsCommands.js"])
	combine_files(contacts, dir + "/js/contacts.js")
	
	# explorer
	explorer = dir_list("js/widgets/explorer", False)
	explorer.extend(["js/portlets/explorerPortlet.js","js/commands/explorerCommands.js"])
	combine_files(explorer, dir + "/js/explorer.js")
	
	# messages
	messages = dir_list("js/widgets/messages", False)
	messages.extend(["js/portlets/messagesPortlet.js","js/commands/messagesCommands.js"])
	combine_files(messages, dir + "/js/messages.js")
	
	# music
	music = dir_list("js/widgets/music", False)
	music.extend(["js/portlets/musicPortlet.js","js/commands/musicCommands.js"])
	combine_files(music, dir + "/js/music.js")
	
	# photos
	photos = ["js/widgets/photos/photoItem.js","js/widgets/photos/photoFolderItem.js", "js/portlets/photosPortlet.js"]
	combine_files(photos, dir + "/js/photos.js")
	
	# ringtones
	ringtones = dir_list("js/widgets/ringtones", False)
	ringtones.extend(["js/portlets/ringtonesPortlet.js","js/commands/ringtonesCommands.js"])
	combine_files(ringtones, dir + "/js/ringtones.js")
	
	# video
	videos = ["js/widgets/videos/videoItem.js", "js/widgets/videos/videoFolderItem.js", "js/widgets/videos/videosList.js","js/portlets/videosPortlet.js"]
	combine_files(videos, dir + "/js/videos.js")
	
	# photo viewer
	photoViewer = ["js/widgets/photos/photoViewer.js","js/portlets/photoViewerPortlet.js"]
	combine_files(photoViewer, dir + "/js/photoViewer.js")
	
	# video viewer
	videoViewer = ["js/utils/mediaplayer.js","js/widgets/videos/videoViewer.js","js/portlets/videoViewerPortlet.js"]
	combine_files(videoViewer, dir + "/js/videoViewer.js")
	
	# media
	media =["js/commands/mediaCommands.js","js/widgets/base/transferList.js","js/widgets/popups/singleUploadPopup.js","js/widgets/popups/selectDestinationPopup.js","js/widgets/popups/informationPopup.js","js/widgets/popups/confirmStopQueryPopup.js", "js/widgets/popups/setRingtonePopup.js"]
	combine_files(media, dir + "/js/media.js")
	
	# messages vs contact popups
	messageContactPopup = ["js/widgets/popups/smileyPopup.js","js/widgets/popups/sendMessage.js","js/widgets/popups/prefillerPopup.js","js/widgets/popups/addContactPopup.js","js/widgets/popups/avatarsPopup.js","js/widgets/popups/avatarItem.js","js/widgets/popups/avatarsList.js"]
	combine_files(messageContactPopup, dir + "/js/messageContactPopup.js")
	
	# photovideo
	photoVideo = ["js/widgets/base/checkGalleryItem.js","js/widgets/photos/photosGallery.js"]
	combine_files(photoVideo, dir + "/js/photoVideo.js")
	
	# photovideo viewer
	photoVideoViewer = ["js/widgets/base/baseViewer.js","js/widgets/photos/caruselItem.js"]
	combine_files(photoVideoViewer, dir + "/js/photoVideoViewer.js")
	
	# contact chooser
	contactChooser = ["js/widgets/popups/contactChooserPopupList.js","js/widgets/popups/contactChooserPopupItem.js","js/widgets/popups/contactEmailsChooserPopupList.js","js/widgets/popups/contactEmailChooserPopupItem.js"]
	combine_files(contactChooser, dir + "/js/contactChooser.js")
		
if __name__ == '__main__':
	# Folder of KiesAir allJS release
	releaseFolder = "release/KiesAir"
	if os.path.isdir(releaseFolder):
		shutil.rmtree(releaseFolder)
		
	copyFiles(releaseFolder)
	makeJSFiles(releaseFolder)